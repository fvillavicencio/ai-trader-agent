// Step 2: Analyze a specific geopolitical event in depth with balanced prompt
async function analyzeGeopoliticalEvent(event, apiKey) {
  // Balanced prompt with diverse sources and comprehensive analysis requirements
  const prompt = `
Analyze this specific geopolitical event in depth:

Headline: "${event.headline}"
Date: ${event.date}
Description: ${event.description}
Region: ${event.region}
Source: ${event.source}

Your task is to provide a FACTUAL, DATA-DRIVEN analysis of this event's impact on financial markets. 
Focus ONLY on VERIFIABLE information from reputable sources. DO NOT invent or fabricate data.

Provide a comprehensive analysis that includes:

1. What specific market sectors and assets are most affected by this event? (Be precise with names of indices, stocks, commodities)
2. What is the quantifiable impact observed so far? (Include REAL percentage changes or price movements)
3. What are expert opinions on this event? Include REAL names and affiliations of analysts who have commented on this event.
4. What are the potential short-term implications for markets based on HISTORICAL PRECEDENT for similar events?

IMPORTANT: Consult a DIVERSE range of sources beyond the original source, including:
- Financial media (Bloomberg, Reuters, Financial Times, Wall Street Journal)
- General news outlets (CNN, BBC, New York Times, The Guardian, Al Jazeera)
- Social media discussions on X (Twitter) from verified financial analysts
- Regional news sources specific to the affected regions

If you cannot find specific information on any of these points, state "Insufficient data available" rather than inventing information.

Format your response as a valid JSON object with the following structure:
{
  "type": "Event/Conflict/Policy",
  "name": "${event.headline}",
  "description": "Factual 3-5 sentence description with specific details from verified sources",
  "region": "${event.region}",
  "impactLevel": 7,  // MUST be a number from 1 to 10, with 1 being least impactful and 10 being most catastrophic
  "marketImpact": "Detailed description of OBSERVED market impact with specific sectors and assets (limit to 4 sentences max)",
  "expertOpinions": [
    {
      "name": "Expert's full name",
      "affiliation": "Expert's organization",
      "opinion": "Direct quote or accurately paraphrased opinion"
    }
  ],
  "sectorImpacts": [
    {
      "sector": "Affected sector name",
      "impact": "Positive/Negative/Mixed",
      "details": "Specific impact details with REAL figures where available"
    }
  ],
  "source": "${event.source}",
  "url": "${event.url || ''}",
  "lastUpdated": "${event.date}"
}
`;

  try {
    console.log(`Analyzing event: ${event.headline}`);
    const response = await callPerplexityAPI(prompt, apiKey, 0.2);
    
    // Extract and parse the JSON
    let analysis;
    try {
      // First try direct parsing
      analysis = JSON.parse(response);
      console.log('Successfully parsed analysis JSON directly');
    } catch (error) {
      console.log('Direct JSON parsing failed, trying to extract from response...');
      
      // Try to extract JSON from markdown code blocks
      const jsonMatch = response.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      if (jsonMatch && jsonMatch[1]) {
        try {
          console.log('Found JSON in code block, attempting to parse...');
          analysis = JSON.parse(jsonMatch[1]);
          console.log('Successfully parsed JSON from code block');
        } catch (codeBlockError) {
          console.error('Failed to parse JSON from code block:', codeBlockError);
        }
      }
      
      // If code block extraction failed, try to find any JSON-like structure
      if (!analysis) {
        const jsonObjectMatch = response.match(/\{[\s\S]*\}/);
        if (jsonObjectMatch) {
          try {
            console.log('Found JSON-like structure, attempting to parse...');
            analysis = JSON.parse(jsonObjectMatch[0]);
            console.log('Successfully parsed JSON from structure match');
          } catch (objectMatchError) {
            console.error('Failed to parse JSON from structure match:', objectMatchError);
          }
        }
      }
    }
    
    // If all parsing attempts failed
    if (!analysis) {
      console.error('All JSON parsing attempts failed for analysis');
      console.log('Raw response (first 500 chars):', response.substring(0, 500));
      
      // Create a minimal fallback that clearly indicates it's a fallback
      analysis = createFallbackAnalysis(event);
    }
    
    // Validate the analysis
    return validateAnalysis(analysis, event);
  } catch (error) {
    console.error(`Error analyzing event ${event.headline}:`, error);
    return createFallbackAnalysis(event);
  }
}

// Step 3: Create a consolidated analysis with proper formatting
function createConsolidatedAnalysis(analyzedEvents) {
  console.log('Creating consolidated analysis from analyzed events...');
  
  // Calculate overall risk index based on individual impact levels
  const avgImpactLevel = analyzedEvents.reduce((sum, event) => {
    return sum + (parseFloat(event.impactLevel) || 5);
  }, 0) / analyzedEvents.length;
  
  // Scale to 0-100
  const geopoliticalRiskIndex = Math.round(avgImpactLevel * 10);
  console.log(`Calculated geopolitical risk index: ${geopoliticalRiskIndex}`);
  
  // Format the risks array to match the required structure
  const risks = analyzedEvents.map(event => {
    // Create expert opinions text - limit to 2 experts to keep description concise
    let expertOpinionsText = '';
    if (event.expertOpinions && Array.isArray(event.expertOpinions) && event.expertOpinions.length > 0) {
      // Filter out any system-generated fallback opinions
      const realOpinions = event.expertOpinions.filter(expert => 
        !expert.name.includes('Unavailable') && 
        !expert.name.includes('Pending') && 
        !expert.affiliation.includes('System')
      );
      
      // Use up to 2 real opinions, or fallback if none
      const opinionsToUse = realOpinions.length > 0 ? realOpinions.slice(0, 2) : event.expertOpinions.slice(0, 1);
      
      expertOpinionsText = opinionsToUse.map(expert => 
        `${expert.name} (${expert.affiliation}): "${expert.opinion}"`
      ).join(' ');
    }
    
    // Enhance description with expert opinions, but keep it concise
    let enhancedDescription = event.description;
    if (expertOpinionsText && !enhancedDescription.includes(expertOpinionsText)) {
      // Check if description is already long
      if (enhancedDescription.length > 300) {
        // If description is already long, don't add expert opinions
        console.log(`Description for ${event.name} already long (${enhancedDescription.length} chars), not adding expert opinions`);
      } else {
        enhancedDescription += ' Experts weigh in: ' + expertOpinionsText;
      }
    }
    
    // Enhance market impact with sector impacts, but keep it concise (max 4 sentences)
    let enhancedMarketImpact = event.marketImpact || '';
    
    // Limit market impact to 4 sentences max
    if (enhancedMarketImpact) {
      const sentences = enhancedMarketImpact.match(/[^.!?]+[.!?]+/g) || [];
      if (sentences.length > 4) {
        enhancedMarketImpact = sentences.slice(0, 4).join(' ');
        console.log(`Truncated market impact for ${event.name} to 4 sentences`);
      }
    }
    
    // Add sector impacts if available
    if (event.sectorImpacts && Array.isArray(event.sectorImpacts) && event.sectorImpacts.length > 0) {
      // Limit to top 3 sector impacts to keep it concise
      const topSectorImpacts = event.sectorImpacts.slice(0, 3);
      const sectorImpactsText = topSectorImpacts.map(sector => 
        `${sector.sector}: ${sector.impact} (${sector.details})`
      ).join('. ');
      
      // Only add if not already included and if we still have room (4 sentences max)
      if (!enhancedMarketImpact.includes(sectorImpactsText)) {
        const currentSentences = enhancedMarketImpact.match(/[^.!?]+[.!?]+/g) || [];
        if (currentSentences.length < 4) {
          enhancedMarketImpact += ' Sector impacts: ' + sectorImpactsText;
          
          // Check again and truncate if needed
          const updatedSentences = enhancedMarketImpact.match(/[^.!?]+[.!?]+/g) || [];
          if (updatedSentences.length > 4) {
            enhancedMarketImpact = updatedSentences.slice(0, 4).join(' ');
          }
        }
      }
    }
    
    return {
      type: event.type || 'Event',
      name: event.name,
      description: enhancedDescription,
      region: event.region,
      impactLevel: parseFloat(event.impactLevel) || 5, // Ensure numeric impact level
      marketImpact: enhancedMarketImpact,
      source: event.source,
      url: event.url,
      lastUpdated: event.lastUpdated
    };
  });
  
  // Sort risks by impact level (highest to lowest)
  risks.sort((a, b) => b.impactLevel - a.impactLevel);
  
  // Create the final result object
  const currentDate = formatDate(new Date());
  
  console.log(`Final analysis contains ${risks.length} geopolitical risks`);
  return {
    geopoliticalRiskIndex,
    risks,
    source: "Perplexity API Enhanced Retrieval",
    sourceUrl: "https://perplexity.ai/",
    lastUpdated: currentDate
  };
}
