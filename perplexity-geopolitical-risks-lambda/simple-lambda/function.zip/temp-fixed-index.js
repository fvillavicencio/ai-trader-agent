// Lambda handler for Perplexity Data Retriever
// Generic handler that supports multiple data retrieval types

const axios = require('axios');
const { parseGeopoliticalRisksFromText, calculateGeopoliticalRiskIndex } = require('./parseFunction');

// Main handler function
exports.handler = async (event = {}) => {
  console.log('Lambda invoked with event:', JSON.stringify(event));
  
  try {
    // Get API key from environment or event
    const apiKey = process.env.PERPLEXITY_API_KEY || event.PERPLEXITY_API_KEY;
    console.log('PERPLEXITY_API_KEY present:', !!apiKey);
    
    if (!apiKey) {
      console.error('PERPLEXITY_API_KEY not provided');
      const errorResponse = { error: 'PERPLEXITY_API_KEY not provided' };
      
      // Check if this is a direct Lambda invocation or an API Gateway request
      if (event.requestContext) {
        return {
          statusCode: 400,
          body: JSON.stringify(errorResponse)
        };
      } else {
        // Direct Lambda invocation - return the data directly
        return errorResponse;
      }
    }

    // Get fallback flag from environment or event
    const useFallback = (process.env.USE_FALLBACK === 'true') || event.useFallback;
    console.log('USE_FALLBACK:', useFallback);

    // If fallback is requested, return fallback data
    if (useFallback) {
      console.log('Using fallback data');
      const fallbackData = createFallbackData();
      
      // Check if this is a direct Lambda invocation or an API Gateway request
      if (event.requestContext) {
        return {
          statusCode: 200,
          body: JSON.stringify(fallbackData)
        };
      } else {
        // Direct Lambda invocation - return the data directly
        return fallbackData;
      }
    }

    // Get request type from event or default to geopoliticalRisks
    const requestType = (event.requestType || 'geopoliticalRisks').toLowerCase();
    console.log('Request type:', requestType);

    // Handle different request types
    let responseData;
    switch (requestType) {
      case 'geopoliticalrisks':
        console.log('Processing geopolitical risks request');
        responseData = await retrieveGeopoliticalRisksEnhanced(apiKey);
        break;
        
      case 'marketsentiment':
        console.log('Market sentiment request type not yet implemented');
        const errorResponse = { 
          error: 'Market sentiment request type not yet implemented',
          timestamp: new Date().toISOString()
        };
        
        // Check if this is a direct Lambda invocation or an API Gateway request
        if (event.requestContext) {
          return {
            statusCode: 400,
            body: JSON.stringify(errorResponse)
          };
        } else {
          // Direct Lambda invocation - return the data directly
          return errorResponse;
        }
        break;
        
      default:
        console.log(`Unknown request type: ${requestType}`);
        const errorResponse = { 
          error: `Unknown request type: ${requestType}`,
          supportedTypes: ['geopoliticalRisks', 'marketSentiment']
        };
        
        // Check if this is a direct Lambda invocation or an API Gateway request
        if (event.requestContext) {
          return {
            statusCode: 400,
            body: JSON.stringify(errorResponse)
          };
        } else {
          // Direct Lambda invocation - return the data directly
          return errorResponse;
        }
    }
    
    // Check if this is a direct Lambda invocation or an API Gateway request
    // If event.requestContext exists, it's coming from API Gateway
    if (event.requestContext) {
      return {
        statusCode: 200,
        body: JSON.stringify(responseData)
      };
    } else {
      // Direct Lambda invocation - return the data directly
      return responseData;
    }
  } catch (error) {
    console.error('Error in Lambda handler:', error);
    const fallbackData = createFallbackData(error);
    const errorResponse = {
      ...fallbackData,
      error: error.message,
      stack: error.stack
    };
    
    // Check if this is a direct Lambda invocation or an API Gateway request
    if (event.requestContext) {
      return {
        statusCode: 500,
        body: JSON.stringify(errorResponse)
      };
    } else {
      // Direct Lambda invocation - return the data directly
      return errorResponse;
    }
  }
};
