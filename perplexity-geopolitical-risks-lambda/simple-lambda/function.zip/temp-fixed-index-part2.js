// Main function to retrieve geopolitical risks data using the enhanced multi-step approach
async function retrieveGeopoliticalRisksEnhanced(apiKey) {
  try {
    console.log("Starting enhanced geopolitical risks retrieval...");
    
    // Step 1: Get recent specific events
    const recentEvents = await getRecentGeopoliticalEvents(apiKey);
    console.log(`Found ${recentEvents.length} recent events`);
    
    // Step 2: Analyze each event in depth
    const analyzedEvents = [];
    for (const event of recentEvents) {
      console.log(`Analyzing event: ${event.headline}`);
      const analysis = await analyzeGeopoliticalEvent(event, apiKey);
      analyzedEvents.push(analysis);
    }
    
    // Step 3: Create consolidated analysis with proper formatting
    const geopoliticalData = createConsolidatedAnalysis(analyzedEvents);
    
    return geopoliticalData;
  } catch (error) {
    console.error(`Error retrieving enhanced geopolitical risks: ${error}`);
    return createFallbackData(error);
  }
}

// Step 1: Get recent specific geopolitical events with balanced prompt
async function getRecentGeopoliticalEvents(apiKey) {
  const currentDate = new Date();
  const formattedDate = formatDate(currentDate);
  
  // Calculate dates for the past 7 days for better context
  const yesterday = new Date(currentDate);
  yesterday.setDate(currentDate.getDate() - 1);
  const twoDaysAgo = new Date(currentDate);
  twoDaysAgo.setDate(currentDate.getDate() - 2);
  
  const yesterdayFormatted = formatDate(yesterday);
  const twoDaysAgoFormatted = formatDate(twoDaysAgo);
  
  // Balanced prompt with diverse sources and coverage requirements
  const prompt = `
Today's Date: ${formattedDate}
Yesterday: ${yesterdayFormatted}
Two Days Ago: ${twoDaysAgoFormatted}

Identify the 7 MOST SIGNIFICANT geopolitical events from the PAST WEEK that are CURRENTLY impacting financial markets.

CRITICAL REQUIREMENTS:
1. Focus on REAL, VERIFIABLE events that have occurred recently
2. Each event MUST have a documented market impact (specific sectors, indices, or assets affected)
3. Each event MUST be from a reputable news source published in the last 7 days
4. Each event MUST include specific details (names, figures, dates)
5. Events should represent a DIVERSE range of regions and event types

ENSURE DIVERSE COVERAGE across these categories:
- Major conflicts or military actions in any region
- Significant diplomatic developments (state visits, treaties, negotiations)
- Central bank decisions and monetary policy changes
- Trade agreements or disputes
- Political transitions or elections with market impact
- Regulatory changes affecting global industries
- Energy market developments
- Natural disasters with economic consequences

SEARCH ACROSS THESE DIVERSE SOURCES:
1. Financial News: Bloomberg, Financial Times, Reuters, Wall Street Journal, CNBC
2. General News: CNN, BBC, New York Times, The Guardian, Al Jazeera, NPR
3. Social Media: Trending topics on X (Twitter) related to markets
4. Research: Major bank research (Goldman Sachs, JPMorgan, Morgan Stanley)
5. Regional Sources: Include sources specific to the regions involved in events

DO NOT OVERREPRESENT any single region, conflict, or type of event. Aim for global coverage.

Format your response as a valid JSON array with the following structure:
[
  {
    "headline": "Brief headline of the event",
    "date": "YYYY-MM-DD", // Must be a real date from the past 7 days
    "description": "Brief 1-2 sentence description of the event with SPECIFIC details",
    "region": "Affected region",
    "source": "Exact source name",
    "url": "Direct URL to specific article"
  }
]
`;

  try {
    console.log('Requesting recent geopolitical events with balanced prompt...');
    const response = await callPerplexityAPI(prompt, apiKey, 0.1);
    
    // Extract and parse the JSON
    let events;
    try {
      // First try direct parsing
      events = JSON.parse(response);
      console.log('Successfully parsed events JSON directly');
    } catch (error) {
      console.log('Direct JSON parsing failed, trying to extract from response...');
      
      // Try to extract JSON from markdown code blocks
      const jsonMatch = response.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      if (jsonMatch && jsonMatch[1]) {
        try {
          console.log('Found JSON in code block, attempting to parse...');
          events = JSON.parse(jsonMatch[1]);
          console.log('Successfully parsed JSON from code block');
        } catch (codeBlockError) {
          console.error('Failed to parse JSON from code block:', codeBlockError);
        }
      }
      
      // If code block extraction failed, try to find any JSON-like structure
      if (!events) {
        const jsonObjectMatch = response.match(/\[\s*\{[\s\S]*\}\s*\]/);
        if (jsonObjectMatch) {
          try {
            console.log('Found JSON-like structure, attempting to parse...');
            events = JSON.parse(jsonObjectMatch[0]);
            console.log('Successfully parsed JSON from structure match');
          } catch (objectMatchError) {
            console.error('Failed to parse JSON from structure match:', objectMatchError);
          }
        }
      }
    }
    
    // If we have events, validate them
    if (Array.isArray(events) && events.length > 0) {
      console.log(`Retrieved ${events.length} events, validating...`);
      
      // Validate each event
      const validatedEvents = events.filter(event => {
        // Check for required fields
        if (!event.headline || !event.date || !event.description || !event.region || !event.source) {
          console.log(`Skipping event missing required fields: ${event.headline || 'Unknown'}`);
          return false;
        }
        
        // Validate date is within the last 7 days
        try {
          const eventDate = new Date(event.date);
          const sevenDaysAgo = new Date();
          sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
          
          if (isNaN(eventDate.getTime()) || eventDate < sevenDaysAgo) {
            console.log(`Skipping event with invalid or old date: ${event.headline}`);
            return false;
          }
        } catch (e) {
          console.log(`Skipping event with unparseable date: ${event.headline}`);
          return false;
        }
        
        return true;
      });
      
      if (validatedEvents.length > 0) {
        console.log(`Validated ${validatedEvents.length} events`);
        return validatedEvents;
      }
    }
    
    // If we get here, either no events were found or none passed validation
    console.log('No valid events found or extracted, using real-world fallbacks');
    return getRealWorldFallbackEvents();
  } catch (error) {
    console.error('Error retrieving geopolitical events:', error);
    return getRealWorldFallbackEvents();
  }
}
