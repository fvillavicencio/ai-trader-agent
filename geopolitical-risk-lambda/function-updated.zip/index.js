/**
 * Geopolitical Risk Lambda Function
 * 
 * This Lambda function provides two operations:
 * 1. Retrieve the latest geopolitical risk JSON, formatted for JsonExport.gs
 * 2. Force a refresh of the data and re-run the analysis
 * 
 * The function implements caching to speed up the retrieval operation.
 */

const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { OpenAI } = require('openai');

// Configuration
const CACHE_DURATION_MS = 15 * 60 * 1000; // 15 minutes
const TMP_DIR = '/tmp';
const RAW_DATA_FILE = path.join(TMP_DIR, 'geopolitical_risks.json');
const ANALYZED_DATA_FILE = path.join(TMP_DIR, 'geopolitical_risks_analyzed.json');
const STATUS_FILE = path.join(TMP_DIR, 'analysis_status.json');

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Global variables for caching
let cachedData = null;
let lastCacheTime = null;
let isProcessing = false;

/**
 * Lambda handler function
 */
exports.handler = async (event, context) => {
  console.log('INFO', 'Received event:', JSON.stringify(event));
  
  try {
    // Determine operation based on HTTP method and body
    const httpMethod = event.httpMethod;
    const body = event.body ? JSON.parse(event.body) : {};
    const operation = body.operation || 'retrieve';
    
    if (httpMethod === 'POST' && operation === 'refresh') {
      // Start refresh operation asynchronously
      startRefreshOperation();
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
          message: 'Refresh operation started',
          status: 'processing'
        })
      };
    } else if (httpMethod === 'GET' && event.queryStringParameters && event.queryStringParameters.status === 'true') {
      // Return current status
      const status = getProcessingStatus();
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify(status)
      };
    } else {
      // Default: retrieve latest data
      const data = await getGeopoliticalRiskData();
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify(data)
      };
    }
  } catch (error) {
    console.error('ERROR', 'Error processing request:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        message: 'Error processing request',
        error: error.message
      })
    };
  }
};

/**
 * Get the current processing status
 */
function getProcessingStatus() {
  try {
    if (fs.existsSync(STATUS_FILE)) {
      const statusData = JSON.parse(fs.readFileSync(STATUS_FILE, 'utf8'));
      return statusData;
    }
    return {
      status: 'unknown',
      lastUpdated: null,
      message: 'Status information not available'
    };
  } catch (error) {
    console.error('ERROR', 'Error reading status file:', error);
    return {
      status: 'error',
      message: 'Error reading status information'
    };
  }
}

/**
 * Update the processing status
 */
function updateProcessingStatus(status, message) {
  try {
    const statusData = {
      status: status,
      lastUpdated: new Date().toISOString(),
      message: message
    };
    fs.writeFileSync(STATUS_FILE, JSON.stringify(statusData));
    return statusData;
  } catch (error) {
    console.error('ERROR', 'Error updating status file:', error);
  }
}

/**
 * Start the refresh operation asynchronously
 */
function startRefreshOperation() {
  if (isProcessing) {
    console.log('INFO', 'Refresh operation already in progress');
    return;
  }
  
  isProcessing = true;
  updateProcessingStatus('processing', 'Refresh operation started');
  
  // Run the refresh operation in the background
  refreshGeopoliticalRiskData()
    .then(() => {
      updateProcessingStatus('completed', 'Refresh operation completed successfully');
      isProcessing = false;
    })
    .catch(error => {
      console.error('ERROR', 'Error in refresh operation:', error);
      updateProcessingStatus('error', `Refresh operation failed: ${error.message}`);
      isProcessing = false;
    });
}

/**
 * Get the latest geopolitical risk data
 */
async function getGeopoliticalRiskData() {
  const now = Date.now();
  
  // Check if we have valid cached data
  if (cachedData && lastCacheTime && (now - lastCacheTime < CACHE_DURATION_MS)) {
    console.log('INFO', 'Returning cached data');
    return cachedData;
  }
  
  // Check if we have data on disk
  if (fs.existsSync(ANALYZED_DATA_FILE)) {
    try {
      console.log('INFO', 'Reading data from disk');
      const data = JSON.parse(fs.readFileSync(ANALYZED_DATA_FILE, 'utf8'));
      cachedData = data;
      lastCacheTime = now;
      return data;
    } catch (error) {
      console.error('ERROR', 'Error reading data from disk:', error);
    }
  }
  
  // If we get here, we need to fetch fresh data
  console.log('INFO', 'Cache expired or not available, fetching fresh data...');
  await refreshGeopoliticalRiskData();
  
  // Read the fresh data from disk
  try {
    const data = JSON.parse(fs.readFileSync(ANALYZED_DATA_FILE, 'utf8'));
    cachedData = data;
    lastCacheTime = now;
    return data;
  } catch (error) {
    throw new Error(`Failed to read analyzed data: ${error.message}`);
  }
}

/**
 * Refresh the geopolitical risk data
 */
async function refreshGeopoliticalRiskData() {
  console.log('INFO', 'Refreshing geopolitical risk data...');
  updateProcessingStatus('processing', 'Fetching raw geopolitical risk data');
  
  // Fetch raw geopolitical risk data
  const rawData = await fetchRawGeopoliticalRiskData();
  
  // Write raw data to disk
  fs.writeFileSync(RAW_DATA_FILE, JSON.stringify(rawData, null, 2));
  console.log('INFO', `Wrote raw risk data to ${RAW_DATA_FILE}`);
  
  // Analyze the data using OpenAI
  updateProcessingStatus('processing', 'Analyzing geopolitical risk data with OpenAI');
  console.log('INFO', 'Sending data to OpenAI for analysis...');
  const analyzedData = await analyzeGeopoliticalRisks(rawData);
  
  // Write analyzed data to disk
  fs.writeFileSync(ANALYZED_DATA_FILE, JSON.stringify(analyzedData, null, 2));
  console.log('INFO', `Wrote analyzed data to ${ANALYZED_DATA_FILE}`);
  
  // Update cache
  cachedData = analyzedData;
  lastCacheTime = Date.now();
  
  updateProcessingStatus('completed', 'Geopolitical risk data refreshed successfully');
  return analyzedData;
}

/**
 * Fetch raw geopolitical risk data
 */
async function fetchRawGeopoliticalRiskData() {
  console.log('INFO', 'Fetching real geopolitical risk data...');
  
  try {
    // Try to fetch data from the API
    const response = await axios.get('https://api.perplexity.ai/chat/completions', {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`
      },
      timeout: 10000 // 10 second timeout
    });
    
    if (response.data && response.data.choices && response.data.choices.length > 0) {
      console.log('INFO', 'Successfully fetched data from Perplexity API');
      return response.data.choices[0].message.content;
    }
  } catch (error) {
    console.error('ERROR', 'Failed to fetch data from Perplexity API:', error.message);
    // Continue to fallback method
  }
  
  // Fallback: Use axios to fetch data from a public API or news source
  try {
    console.log('INFO', 'Fetching geopolitical risk data from RapidAPI...');
    const response = await axios.get(process.env.RAPIDAPI_ENDPOINT, {
      headers: {
        'X-RapidAPI-Key': process.env.RAPIDAPI_KEY,
        'X-RapidAPI-Host': process.env.RAPIDAPI_HOST
      },
      timeout: 10000 // 10 second timeout
    });
    
    if (response.data && response.data.items) {
      console.log('INFO', `Successfully fetched ${response.data.items.length} items from RapidAPI`);
      
      // Transform the data to match our expected format
      return response.data.items.map(item => ({
        id: item.id || `risk-${Math.floor(Math.random() * 1000)}`,
        name: item.title || 'Unknown Risk',
        description: item.description || item.summary || 'No description available',
        source: item.source || 'Unknown Source',
        sourceUrl: item.url || '',
        publishedDate: item.published_date || new Date().toISOString(),
        impactLevel: item.risk_level || 5,
        regions: item.regions || ['Global'],
        categories: item.categories || ['geopolitical']
      }));
    }
  } catch (error) {
    console.error('ERROR', 'Failed to fetch data from RapidAPI:', error.message);
    // Continue to fallback method
  }
  
  // Final fallback: Use a set of current geopolitical risks
  console.log('INFO', 'Using fallback geopolitical risk data');
  return [
    {
      "id": "risk-1",
      "name": "US-China Tensions in South China Sea",
      "description": "Escalating military posturing and territorial disputes in the South China Sea",
      "source": "Council on Foreign Relations",
      "sourceUrl": "https://www.cfr.org/global-conflict-tracker/conflict/tensions-south-china-sea",
      "publishedDate": new Date().toISOString(),
      "impactLevel": 8,
      "regions": ["East Asia", "Global"],
      "categories": ["geopolitical"]
    },
    {
      "id": "risk-2",
      "name": "Russia-Ukraine Conflict",
      "description": "Ongoing military conflict with global economic implications",
      "source": "BBC News",
      "sourceUrl": "https://www.bbc.com/news/world-europe-60506682",
      "publishedDate": new Date().toISOString(),
      "impactLevel": 9,
      "regions": ["Eastern Europe"],
      "categories": ["geopolitical"]
    },
    {
      "id": "risk-3",
      "name": "Middle East Tensions",
      "description": "Ongoing conflict between Israel and Hamas with regional implications",
      "source": "Al Jazeera",
      "sourceUrl": "https://www.aljazeera.com/news/2023/10/7/israel-palestine-war",
      "publishedDate": new Date().toISOString(),
      "impactLevel": 8,
      "regions": ["Middle East"],
      "categories": ["geopolitical"]
    },
    {
      "id": "risk-4",
      "name": "North Korean Nuclear Threats",
      "description": "Continued development of nuclear capabilities and missile tests",
      "source": "Reuters",
      "sourceUrl": "https://www.reuters.com/world/asia-pacific/",
      "publishedDate": new Date().toISOString(),
      "impactLevel": 7,
      "regions": ["East Asia", "Global"],
      "categories": ["geopolitical"]
    },
    {
      "id": "risk-5",
      "name": "Iran Nuclear Program",
      "description": "Tensions over Iran's nuclear program and potential for regional escalation",
      "source": "Foreign Policy",
      "sourceUrl": "https://foreignpolicy.com/",
      "publishedDate": new Date().toISOString(),
      "impactLevel": 7,
      "regions": ["Middle East", "Global"],
      "categories": ["geopolitical"]
    }
  ];
}

/**
 * Analyze geopolitical risks using OpenAI
 */
async function analyzeGeopoliticalRisks(rawData) {
  // Prepare the prompt for OpenAI
  const prompt = `
Analyze the following geopolitical risks and create a structured JSON output with:
1. A geopolitical risk index (0-100, where 100 is highest risk)
2. A concise global overview (max 150 characters)
3. A detailed executive summary (max 500 words)
4. Categorized risks with impact levels

Raw data:
${JSON.stringify(rawData, null, 2)}

Important: Use the actual data provided above. Extract real geopolitical risks from the data, not generic examples.
Preserve the original source URLs and publication dates from the input data whenever possible.
Group similar risks into thematic categories (e.g., "Middle East Tensions", "US-China Relations", etc.).
Assign impact levels based on the impactLevel field in the data (if available) or your assessment of severity.

Format the response as valid JSON with this structure:
{
  "lastUpdated": "<current date in ISO format>",
  "geopoliticalRiskIndex": <number 0-100>,
  "global": "<highly concise global overview>",
  "summary": "<detailed executive summary>",
  "risks": [
    {
      "name": "<thematic grouping name>",
      "description": "<synthesized description>",
      "region": "<affected regions>",
      "impactLevel": "<High/Medium/Low>",
      "source": "<primary source>",
      "sourceUrl": "<source URL>",
      "relatedSources": [
        {
          "name": "<source name>",
          "url": "<source URL>",
          "timestamp": "<publication timestamp>"
        }
      ]
    }
  ]
}
`;

  // Call OpenAI API with retry logic
  const maxRetries = 3;
  let attempt = 0;
  let response;
  
  while (attempt < maxRetries) {
    attempt++;
    console.log('INFO', `API call attempt ${attempt} of ${maxRetries}`);
    
    try {
      response = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: 'You are a geopolitical risk analyst providing JSON-formatted analysis.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.2,
        max_tokens: 2000
      });
      
      console.log('INFO', 'API call successful');
      break;
    } catch (error) {
      if (attempt === maxRetries) {
        throw new Error(`Failed to call OpenAI API after ${maxRetries} attempts: ${error.message}`);
      }
      console.error('ERROR', `API call failed (attempt ${attempt}): ${error.message}`);
      // Wait before retrying
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
    }
  }
  
  // Process the response
  const responseContent = response.choices[0].message.content;
  console.log('INFO', `Received response from OpenAI with length: ${responseContent.length} characters`);
  console.log('INFO', `Response starts with: ${responseContent.substring(0, 100)}...`);
  
  // Parse the JSON response
  try {
    // Try to parse the response directly
    const parsedData = JSON.parse(responseContent);
    console.log('INFO', 'Successfully parsed JSON directly');
    return parsedData;
  } catch (error) {
    console.error('ERROR', 'Failed to parse response as JSON:', error);
    
    // Try to extract JSON from the response
    const jsonMatch = responseContent.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        const extractedJson = jsonMatch[0];
        console.log('INFO', 'Extracted JSON from response');
        return JSON.parse(extractedJson);
      } catch (extractError) {
        console.error('ERROR', 'Failed to extract and parse JSON:', extractError);
      }
    }
    
    throw new Error('Failed to parse OpenAI response as JSON');
  }
}
