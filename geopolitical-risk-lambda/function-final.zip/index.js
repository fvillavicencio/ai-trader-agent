/**
 * Geopolitical Risk Lambda Function
 * 
 * This Lambda function provides two operations:
 * 1. Retrieve the latest geopolitical risk JSON, formatted for JsonExport.gs
 * 2. Force a refresh of the data and re-run the analysis
 * 
 * The function implements caching to speed up the retrieval operation.
 */

const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { OpenAI } = require('openai');

// Configuration
const CACHE_DURATION_MS = 15 * 60 * 1000; // 15 minutes
const TMP_DIR = '/tmp';
const RAW_DATA_FILE = path.join(TMP_DIR, 'geopolitical_risks.json');
const ANALYZED_DATA_FILE = path.join(TMP_DIR, 'geopolitical_risks_analyzed.json');
const STATUS_FILE = path.join(TMP_DIR, 'analysis_status.json');

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Global variables for caching
let cachedData = null;
let lastCacheTime = null;
let isProcessing = false;

/**
 * Lambda handler function
 */
exports.handler = async (event, context) => {
  console.log('INFO', 'Received event:', JSON.stringify(event));
  
  try {
    // Log available environment variables for debugging (excluding sensitive values)
    const safeEnvVars = Object.keys(process.env)
      .filter(key => !key.includes('KEY') && !key.includes('SECRET') && !key.includes('TOKEN'))
      .reduce((obj, key) => {
        obj[key] = process.env[key];
        return obj;
      }, {});
    console.log('INFO', 'Environment variables:', JSON.stringify(safeEnvVars));
    
    // Check if this is a status check request
    if (event.queryStringParameters && event.queryStringParameters.status === 'true') {
      console.log('INFO', 'Processing status check request');
      return await getStatusResponse();
    }
    
    // Check if this is a refresh request
    if (event.httpMethod === 'POST' && event.body) {
      try {
        const body = JSON.parse(event.body);
        if (body.operation === 'refresh') {
          console.log('INFO', 'Processing refresh request');
          return await handleRefreshRequest();
        }
      } catch (parseError) {
        console.error('ERROR', `Failed to parse request body: ${parseError.message}`);
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          },
          body: JSON.stringify({ 
            error: 'Bad Request', 
            message: 'Invalid JSON in request body',
            status: 'error'
          })
        };
      }
    }
    
    // Regular request - return cached data if available and not expired
    console.log('INFO', 'Processing regular data request');
    const cachedData = await getCachedData();
    if (cachedData) {
      console.log('INFO', 'Returning cached data');
      console.log('INFO', `Cached data contains ${cachedData.risks ? cachedData.risks.length : 0} risk items`);
      console.log('INFO', `Cached data last updated: ${cachedData.lastUpdated}`);
      
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'max-age=900' // 15 minutes client-side caching
        },
        body: JSON.stringify(cachedData)
      };
    }
    
    // No valid cached data, start async processing and return status
    console.log('INFO', 'No valid cached data found, starting async processing');
    await startAsyncProcessing();
    
    return {
      statusCode: 202,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        message: 'Geopolitical risk data is being processed. Please check back in a few moments.',
        status: 'processing',
        requestId: context.awsRequestId || `local-${Date.now()}`
      })
    };
  } catch (error) {
    console.error('ERROR', `Lambda handler error: ${error.message}`);
    console.error('ERROR', `Error stack: ${error.stack}`);
    
    // Log all available information for debugging
    try {
      console.error('ERROR', 'Event details:', JSON.stringify(event));
      console.error('ERROR', 'Context details:', JSON.stringify({
        functionName: context.functionName,
        functionVersion: context.functionVersion,
        memoryLimitInMB: context.memoryLimitInMB,
        awsRequestId: context.awsRequestId,
        logGroupName: context.logGroupName,
        logStreamName: context.logStreamName,
        remainingTime: context.getRemainingTimeInMillis ? context.getRemainingTimeInMillis() : 'N/A'
      }));
    } catch (logError) {
      console.error('ERROR', 'Failed to log additional debug info:', logError.message);
    }
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ 
        error: 'Internal server error', 
        message: error.message,
        status: 'error',
        requestId: context.awsRequestId || `local-${Date.now()}`
      })
    };
  }
};

/**
 * Get the current processing status
 */
async function getStatusResponse() {
  try {
    if (fs.existsSync(STATUS_FILE)) {
      const statusData = JSON.parse(fs.readFileSync(STATUS_FILE, 'utf8'));
      console.log('INFO', `Retrieved status: ${statusData.status}, message: ${statusData.message}`);
      
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'no-cache'
        },
        body: JSON.stringify(statusData)
      };
    }
    
    // If no status file exists, check if we have cached data
    if (await getCachedData()) {
      const status = {
        status: 'completed',
        lastUpdated: new Date().toISOString(),
        message: 'Data is available'
      };
      
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'no-cache'
        },
        body: JSON.stringify(status)
      };
    }
    
    // No status file and no cached data
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'no-cache'
      },
      body: JSON.stringify({
        status: 'unknown',
        lastUpdated: null,
        message: 'Status information not available'
      })
    };
  } catch (error) {
    console.error('ERROR', `Error getting status: ${error.message}`);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        status: 'error',
        message: `Error reading status information: ${error.message}`
      })
    };
  }
}

/**
 * Handle a refresh request
 */
async function handleRefreshRequest() {
  try {
    // Check if a refresh is already in progress
    if (fs.existsSync(STATUS_FILE)) {
      const statusData = JSON.parse(fs.readFileSync(STATUS_FILE, 'utf8'));
      if (statusData.status === 'processing') {
        console.log('INFO', 'Refresh operation already in progress');
        return {
          statusCode: 200,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          },
          body: JSON.stringify({
            message: 'Refresh operation already in progress',
            status: 'processing'
          })
        };
      }
    }
    
    // Start the refresh operation asynchronously
    await startAsyncProcessing(true);
    
    return {
      statusCode: 202,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        message: 'Refresh operation started',
        status: 'processing'
      })
    };
  } catch (error) {
    console.error('ERROR', `Error handling refresh request: ${error.message}`);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        status: 'error',
        message: `Refresh operation failed: ${error.message}`
      })
    };
  }
}

/**
 * Update the processing status
 */
function updateProcessingStatus(status, message) {
  try {
    const statusData = {
      status: status,
      lastUpdated: new Date().toISOString(),
      message: message
    };
    fs.writeFileSync(STATUS_FILE, JSON.stringify(statusData, null, 2));
    console.log('INFO', `Updated status: ${status}, message: ${message}`);
    return statusData;
  } catch (error) {
    console.error('ERROR', `Error updating status file: ${error.message}`);
    return null;
  }
}

/**
 * Get cached data if available and not expired
 */
async function getCachedData() {
  try {
    // Check if we have data in the ANALYZED_DATA_FILE
    if (fs.existsSync(ANALYZED_DATA_FILE)) {
      const stats = fs.statSync(ANALYZED_DATA_FILE);
      const fileModTime = stats.mtime.getTime();
      const now = Date.now();
      
      // Check if the file is recent enough (within CACHE_DURATION_MS)
      if (now - fileModTime < CACHE_DURATION_MS) {
        console.log('INFO', `Found valid cached data (age: ${Math.round((now - fileModTime) / 1000)} seconds)`);
        
        // Read and parse the file
        const fileContent = fs.readFileSync(ANALYZED_DATA_FILE, 'utf8');
        const data = JSON.parse(fileContent);
        
        // Validate the data structure
        if (!data || !data.risks || !Array.isArray(data.risks)) {
          console.warn('WARN', 'Cached data has invalid structure');
          return null;
        }
        
        // Check if the data has content
        if (data.risks.length === 0) {
          console.warn('WARN', 'Cached data contains empty risks array');
          return null;
        }
        
        return data;
      } else {
        console.log('INFO', `Cached data expired (age: ${Math.round((now - fileModTime) / 60000)} minutes)`);
      }
    } else {
      console.log('INFO', 'No cached data file found');
    }
    
    return null;
  } catch (error) {
    console.error('ERROR', `Error reading cached data: ${error.message}`);
    return null;
  }
}

/**
 * Start asynchronous processing of geopolitical risk data
 */
async function startAsyncProcessing(forceRefresh = false) {
  // Create a unique ID for this processing job
  const jobId = `job-${Date.now()}`;
  console.log('INFO', `Starting async processing job ${jobId}`);
  
  // Update status to indicate processing has started
  updateProcessingStatus('processing', 'Fetching raw geopolitical risk data');
  
  // Start the processing in the background
  setTimeout(async () => {
    try {
      console.log('INFO', `Executing background job ${jobId}`);
      
      // Fetch raw geopolitical risk data
      const rawData = await fetchRawGeopoliticalRiskData();
      
      // Check if we have valid data
      if (!Array.isArray(rawData) || rawData.length === 0) {
        throw new Error('Failed to retrieve valid geopolitical risk data');
      }
      
      // Write raw data to disk for debugging
      fs.writeFileSync(RAW_DATA_FILE, JSON.stringify(rawData, null, 2));
      console.log('INFO', `Wrote ${rawData.length} raw risk items to ${RAW_DATA_FILE}`);
      
      // Update status
      updateProcessingStatus('processing', 'Analyzing geopolitical risk data with OpenAI');
      
      // Analyze the data using OpenAI
      console.log('INFO', 'Sending data to OpenAI for analysis...');
      const analyzedData = await analyzeGeopoliticalRisks(rawData);
      
      // Write analyzed data to disk
      fs.writeFileSync(ANALYZED_DATA_FILE, JSON.stringify(analyzedData, null, 2));
      console.log('INFO', `Wrote analyzed data to ${ANALYZED_DATA_FILE}`);
      
      // Update status to indicate completion
      updateProcessingStatus('completed', 'Geopolitical risk data refreshed successfully');
      console.log('INFO', `Background job ${jobId} completed successfully`);
    } catch (error) {
      console.error('ERROR', `Background job ${jobId} failed: ${error.message}`);
      console.error('ERROR', `Error stack: ${error.stack}`);
      updateProcessingStatus('error', `Refresh operation failed: ${error.message}`);
    }
  }, 10); // Start after 10ms to allow the Lambda handler to return
  
  return jobId;
}

/**
 * Fetch raw geopolitical risk data
 */
async function fetchRawGeopoliticalRiskData() {
  console.log('INFO', 'Starting to fetch real geopolitical risk data...');
  
  // Define paths to try for the geopolitical risks data file
  const dataPaths = [
    // Path in the Lambda deployment package
    path.join(__dirname, 'data', 'geopolitical_risks.json'),
    // Path in the /tmp directory (in case it was previously cached)
    path.join(TMP_DIR, 'geopolitical_risks.json'),
    // Absolute path for local development
    path.resolve(process.cwd(), 'data', 'geopolitical_risks.json')
  ];
  
  // Try to fetch from external API first
  try {
    console.log('INFO', 'Attempting to fetch geopolitical risk data from external API');
    
    // Use environment variable for API endpoint
    const apiEndpoint = process.env.RAPIDAPI_ENDPOINT;
    if (!apiEndpoint) {
      console.warn('WARN', 'No RAPIDAPI_ENDPOINT environment variable found');
      throw new Error('No API endpoint configured');
    }
    
    // Fetch the data from the API
    const response = await axios.get(apiEndpoint, {
      headers: {
        'X-RapidAPI-Key': process.env.RAPIDAPI_KEY,
        'X-RapidAPI-Host': process.env.RAPIDAPI_HOST,
        'Accept': 'application/json'
      },
      timeout: 15000 // 15 second timeout
    });
    
    // Process the API response
    if (response.data && response.data.items && Array.isArray(response.data.items) && response.data.items.length > 0) {
      console.log('INFO', `Successfully fetched ${response.data.items.length} items from API`);
      
      // Transform the data to our expected format
      const transformedData = response.data.items.map(item => ({
        id: item.id || `risk-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
        name: item.title || item.name || 'Untitled Risk',
        description: item.description || item.summary || 'No description available',
        source: item.source || 'Unknown Source',
        sourceUrl: item.url || '',
        publishedDate: item.published_date || item.publishedDate || new Date().toISOString(),
        impactLevel: item.risk_level || item.impactLevel || 5,
        regions: item.regions || ['Global'],
        categories: item.categories || ['geopolitical']
      }));
      
      // Cache the transformed data
      fs.writeFileSync(path.join(TMP_DIR, 'geopolitical_risks.json'), JSON.stringify(transformedData, null, 2));
      console.log('INFO', `Cached ${transformedData.length} items to ${path.join(TMP_DIR, 'geopolitical_risks.json')}`);
      
      return transformedData;
    } else {
      console.warn('WARN', 'API response did not contain valid items array');
      throw new Error('Invalid API response format');
    }
  } catch (apiError) {
    console.error('ERROR', `Failed to fetch from API: ${apiError.message}`);
    // Continue to try local files
  }
  
  // Try each path in sequence
  for (const dataPath of dataPaths) {
    try {
      console.log('INFO', `Attempting to read geopolitical risk data from: ${dataPath}`);
      
      // Check if the file exists
      if (!fs.existsSync(dataPath)) {
        console.warn('WARN', `File not found at: ${dataPath}`);
        continue; // Try next path
      }
      
      // Read and parse the file
      const fileContent = fs.readFileSync(dataPath, 'utf8');
      const data = JSON.parse(fileContent);
      
      // Validate the data
      if (!Array.isArray(data)) {
        console.warn('WARN', `Data at ${dataPath} is not an array`);
        continue; // Try next path
      }
      
      if (data.length === 0) {
        console.warn('WARN', `Data at ${dataPath} is an empty array`);
        continue; // Try next path
      }
      
      // Log success
      console.log('INFO', `Successfully read ${data.length} geopolitical risk items from ${dataPath}`);
      console.log('INFO', `First item: ${JSON.stringify(data[0]).substring(0, 200)}...`);
      
      // Cache the data in the tmp directory for future use
      if (dataPath !== path.join(TMP_DIR, 'geopolitical_risks.json')) {
        fs.writeFileSync(path.join(TMP_DIR, 'geopolitical_risks.json'), JSON.stringify(data, null, 2));
        console.log('INFO', `Cached data to ${path.join(TMP_DIR, 'geopolitical_risks.json')}`);
      }
      
      return data;
    } catch (error) {
      console.error('ERROR', `Failed to read from ${dataPath}: ${error.message}`);
      // Continue to the next path
    }
  }
  
  // If we get here, all attempts have failed
  console.error('ERROR', 'All attempts to fetch geopolitical risk data have failed');
  
  // Instead of throwing an error, return an empty array
  // This follows the principle of not using hardcoded fallbacks
  console.log('INFO', 'Returning empty array as fallback');
  return [];
}

/**
 * Analyze geopolitical risks using OpenAI
 */
async function analyzeGeopoliticalRisks(rawData) {
  console.log('INFO', 'Analyzing geopolitical risks...');
  console.log('INFO', `Processing ${rawData.length} raw data items`);
  
  // Initialize OpenAI client
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
  });
  
  // Save raw data for debugging
  const rawDataPath = path.join(TMP_DIR, 'raw_data_for_analysis.json');
  fs.writeFileSync(rawDataPath, JSON.stringify(rawData, null, 2));
  console.log('INFO', `Saved raw data for OpenAI analysis to ${rawDataPath}`);
  
  // Limit the number of items to process to avoid token limits
  // Sort by date if available to get the most recent items
  const sortedData = [...rawData].sort((a, b) => {
    try {
      // Safely handle date comparison with fallbacks
      const dateA = a.publishedDate || a.date || '';
      const dateB = b.publishedDate || b.date || '';
      
      // Convert to strings if they aren't already
      const strDateA = String(dateA);
      const strDateB = String(dateB);
      
      // Compare dates (most recent first)
      return strDateB.localeCompare(strDateA);
    } catch (error) {
      console.warn('WARN', `Error comparing dates: ${error.message}`);
      return 0; // Keep original order if comparison fails
    }
  });
  
  // Take the most recent 15 items
  const limitedData = sortedData.slice(0, 15);
  console.log('INFO', `Limited to ${limitedData.length} most recent items`);
  
  // Truncate long descriptions to reduce token count
  const processedData = limitedData.map(item => ({
    id: item.id,
    name: item.name,
    description: item.description ? item.description.substring(0, 200) + (item.description.length > 200 ? '...' : '') : '',
    source: item.source,
    sourceUrl: item.sourceUrl || item.url || '',
    publishedDate: item.publishedDate || item.date || new Date().toISOString(),
    regions: Array.isArray(item.regions) ? item.regions : [item.region || 'Global'],
    categories: Array.isArray(item.categories) ? item.categories : ['geopolitical']
  }));
  
  // Save processed data for debugging
  const processedDataPath = path.join(TMP_DIR, 'processed_data_for_analysis.json');
  fs.writeFileSync(processedDataPath, JSON.stringify(processedData, null, 2));
  console.log('INFO', `Saved processed data for OpenAI analysis to ${processedDataPath}`);
  
  // Prepare a more efficient prompt
  let prompt = `Analyze these ${processedData.length} geopolitical risks and create a structured analysis:

${JSON.stringify(processedData, null, 1)}

Your task:
1. Calculate a global geopolitical risk index (0-100) based on the severity and scope of current risks
2. Write a concise global overview (1-2 sentences)
3. Create a detailed executive summary (max 500 words)
4. Categorize the risks into thematic groups with appropriate impact levels

Response MUST be valid JSON with this structure:
{
  "lastUpdated": "${new Date().toISOString()}",
  "geopoliticalRiskIndex": <number 0-100>,
  "global": "<concise global overview>",
  "summary": "<executive summary>",
  "risks": [
    {
      "name": "<thematic category>",
      "description": "<brief description>",
      "region": "<affected regions>",
      "impactLevel": "<High/Medium/Low>",
      "source": "<primary source>",
      "sourceUrl": "<source URL>"
    }
  ]
}`;
  
  console.log('INFO', `Prompt length: ${prompt.length} characters`);
  
  // Call OpenAI API with retry logic
  const maxRetries = 3;
  let attempt = 0;
  let response;
  
  while (attempt < maxRetries) {
    attempt++;
    console.log('INFO', `OpenAI API call attempt ${attempt} of ${maxRetries}`);
    
    try {
      // Use GPT-3.5-turbo for lower token usage if we're having issues with GPT-4
      const model = attempt <= 2 ? 'gpt-4' : 'gpt-3.5-turbo';
      console.log('INFO', `Making OpenAI API call with ${model} model`);
      
      response = await openai.chat.completions.create({
        model: model,
        messages: [
          { 
            role: 'system', 
            content: 'You are a geopolitical risk analyst. Respond ONLY with valid JSON.' 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.2,
        max_tokens: 2000
      });
      
      console.log('INFO', 'OpenAI API call successful');
      console.log('INFO', `Response model: ${response.model}, finish reason: ${response.choices[0].finish_reason}`);
      break;
    } catch (error) {
      console.error('ERROR', `OpenAI API call failed (attempt ${attempt}): ${error.message}`);
      
      // If token limit error and using GPT-4, try with a more summarized prompt
      if (error.message.includes('maximum context length') && attempt === 1) {
        console.log('INFO', 'Token limit exceeded, reducing prompt size...');
        // Further reduce the data size
        processedData.forEach(item => {
          item.description = item.description.substring(0, 100) + '...';
        });
        prompt = `Analyze these geopolitical risks and create a structured analysis:
${JSON.stringify(processedData.map(d => ({name: d.name, source: d.source})), null, 1)}
Create a concise JSON analysis with risk index (0-100), global overview, summary, and 5-7 risk categories.`;
        console.log('INFO', `Reduced prompt length: ${prompt.length} characters`);
      }
      
      if (attempt === maxRetries) {
        throw new Error(`Failed to call OpenAI API after ${maxRetries} attempts: ${error.message}`);
      }
      
      // Wait before retrying with exponential backoff
      const backoffTime = 1000 * Math.pow(2, attempt);
      console.log('INFO', `Waiting ${backoffTime}ms before retry...`);
      await new Promise(resolve => setTimeout(resolve, backoffTime));
    }
  }
  
  // Process the response
  const responseContent = response.choices[0].message.content;
  console.log('INFO', `Received response from OpenAI with length: ${responseContent.length} characters`);
  console.log('INFO', `Response preview: ${responseContent.substring(0, 200)}...`);
  
  // Save the raw response for debugging
  const responsePath = path.join(TMP_DIR, 'openai_response_raw.json');
  fs.writeFileSync(responsePath, responseContent);
  console.log('INFO', `Saved raw OpenAI response to ${responsePath}`);
  
  // Parse the JSON response
  try {
    // Try to parse the response directly
    const parsedData = JSON.parse(responseContent);
    console.log('INFO', 'Successfully parsed OpenAI response as JSON');
    console.log('INFO', `Parsed data contains ${parsedData.risks ? parsedData.risks.length : 0} risk categories`);
    
    // Validate the parsed data
    if (!parsedData.geopoliticalRiskIndex || !parsedData.global || !parsedData.summary || !Array.isArray(parsedData.risks)) {
      console.error('ERROR', 'Parsed data is missing required fields');
      console.error('ERROR', `Data structure: ${JSON.stringify(Object.keys(parsedData))}`);
      throw new Error('OpenAI response is missing required fields');
    }
    
    // Save the parsed response for debugging
    const parsedPath = path.join(TMP_DIR, 'openai_response_parsed.json');
    fs.writeFileSync(parsedPath, JSON.stringify(parsedData, null, 2));
    console.log('INFO', `Saved parsed OpenAI response to ${parsedPath}`);
    
    return parsedData;
  } catch (error) {
    console.error('ERROR', `Failed to parse OpenAI response as JSON: ${error.message}`);
    
    // Try to extract JSON from the response
    console.log('INFO', 'Attempting to extract JSON from response...');
    const jsonMatch = responseContent.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        const extractedJson = jsonMatch[0];
        console.log('INFO', `Extracted JSON-like content (${extractedJson.length} chars)`);
        const parsedExtracted = JSON.parse(extractedJson);
        console.log('INFO', 'Successfully parsed extracted JSON');
        
        // Save the extracted JSON for debugging
        const extractedPath = path.join(TMP_DIR, 'openai_response_extracted.json');
        fs.writeFileSync(extractedPath, JSON.stringify(parsedExtracted, null, 2));
        console.log('INFO', `Saved extracted JSON to ${extractedPath}`);
        
        return parsedExtracted;
      } catch (extractError) {
        console.error('ERROR', `Failed to extract and parse JSON: ${extractError.message}`);
        console.error('ERROR', 'Extraction failed, saving problematic response for debugging');
        fs.writeFileSync(path.join(TMP_DIR, 'openai_response_problematic.txt'), responseContent);
      }
    }
    
    // If all parsing attempts fail, throw a detailed error
    throw new Error(`Failed to parse OpenAI response as JSON: ${error.message}. See logs for details.`);
  }
}
